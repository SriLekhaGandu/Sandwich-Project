package com.udacity.sandwichclub;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;

import org.json.JSONException;

import java.util.List;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "extra_position";
    private static final int DEFAULT_POSITION = -1;
    TextView tv_placeOfOrigin, tv_alsoKnownAs, tv_description, tv_ingredients;
    String placeOfOrigin, description;
    List<String> ingredients;
    List<String> alsoKnownAs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ImageView ingredientsIv = findViewById(R.id.image_iv);
        tv_alsoKnownAs = findViewById(R.id.also_known_tv);
        tv_placeOfOrigin = findViewById(R.id.origin_tv);
        tv_description = findViewById(R.id.description_tv);
        tv_ingredients = findViewById(R.id.ingredients_tv);
        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        int position = intent.getIntExtra(EXTRA_POSITION, DEFAULT_POSITION);
        if (position == DEFAULT_POSITION) {
            // EXTRA_POSITION not found in intent
            closeOnError();
            return;
        }

        String[] sandwiches = getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
        Sandwich sandwich = null;
        try {
            sandwich = JsonUtils.parseSandwichJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (sandwich == null) {
            // Sandwich data unavailable
            closeOnError();
            return;
        }
        placeOfOrigin = sandwich.getPlaceOfOrigin();
        alsoKnownAs = sandwich.getAlsoKnownAs();
        description = sandwich.getDescription();
        ingredients = sandwich.getIngredients();
        populateUI();
        Picasso.with(this)
                .load(sandwich.getImage())
                .into(ingredientsIv, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {
                        Toast.makeText(DetailActivity.this, "Loading Image Failed", Toast.LENGTH_SHORT).show();
                    }
                });

        if (sandwich.getImage() == null) {
            Toast.makeText(DetailActivity.this, "No image to display", Toast.LENGTH_SHORT).show();
        }
        setTitle(sandwich.getMainName());
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.detail_error_message, Toast.LENGTH_SHORT).show();
    }

    private void populateUI() {
        if (placeOfOrigin.length() != 0)
            tv_placeOfOrigin.setText(placeOfOrigin);
        else {
            tv_placeOfOrigin.setText("No data found");
            tv_placeOfOrigin.setTextColor(Color.RED);
        }
        if (description.length() != 0) {
            tv_description.setText(description);
        } else {
            tv_description.setText("No description found");
            tv_description.setTextColor(Color.RED);
        }
        int i = 0;
        if (alsoKnownAs.size() == 0) {
            tv_alsoKnownAs.setText("No other names");
            tv_alsoKnownAs.setTextColor(Color.RED);
        }
        while (i < alsoKnownAs.size()) {
            if (alsoKnownAs.size() > 1)
                tv_alsoKnownAs.append("" + (i + 1) + ":" + alsoKnownAs.get(i) + "\n");
            else
                tv_alsoKnownAs.append(alsoKnownAs.get(i) + "\n");

            i++;
        }
        i = 0;
        if (ingredients.size() == 0) {
            tv_ingredients.setTextColor(Color.RED);
            tv_ingredients.setText("No data available");
        } else {

            while (i < ingredients.size()) {
                tv_ingredients.append("" + (i + 1) + ":" + ingredients.get(i) + "\n");
                i++;

            }
        }
    }
}