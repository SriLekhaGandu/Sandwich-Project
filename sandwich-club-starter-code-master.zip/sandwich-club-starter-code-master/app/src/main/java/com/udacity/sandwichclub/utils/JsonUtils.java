package com.udacity.sandwichclub.utils;

import android.util.Log;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {
    public static Sandwich parseSandwichJson(String json) throws JSONException {
        Sandwich sandwich = new Sandwich();
        List<String> sand_alsoKnownAs = new ArrayList<String>();
        List<String> sand_ingredients = new ArrayList<String>();
        String sand_mainName = "";
        String sand_placeOfOrigin = "";
        String sand_description = "";
        String sand_image = "";
        JSONObject name;
        JSONObject jsonObject = new JSONObject(json);
        name = jsonObject.getJSONObject("name");
        sand_mainName = name.getString("mainName");
        JSONArray jsonArray = name.getJSONArray("alsoKnownAs");
        int i = 0;
        while (i < jsonArray.length()) {
            sand_alsoKnownAs.add(jsonArray.getString(i));
            i++;
        }
        sand_placeOfOrigin = jsonObject.getString("placeOfOrigin");
        sand_description = jsonObject.getString("description");
        sand_image = jsonObject.getString("image");
        JSONArray jsonArray1 = jsonObject.getJSONArray("ingredients");
        i = 0;
        while (i < jsonArray1.length()) {
            sand_ingredients.add(jsonArray1.getString(i));
            i++;
        }
        sandwich = new Sandwich(sand_mainName, sand_alsoKnownAs, sand_placeOfOrigin, sand_description, sand_image, sand_ingredients);
        return sandwich;
    }
}
